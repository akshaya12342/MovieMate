import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { searchMovieDetails } from '../services/Apicall';

function Search() {
  const { search } = useLocation();
  const navigate = useNavigate();
  const q = new URLSearchParams(search).get('word') || '';
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    if (!q) return;
    (async () => {
      try {
        const res = await searchMovieDetails(q);
        setMovies(res.data || []);
      } catch (err) {
        console.error(err);
        setMovies([]);
      }
    })();
  }, [q]);

  const handleDetails = (id) => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please login to view details.');
      navigate('/login');
    } else {
      navigate(`/detail?id=${id}`);
    }
  };

  return (
    <div className="container mt-5">
      <h3 className="text-center mb-4">
        Search results for: <span className="text-danger">{q}</span>
      </h3>

      <div className="row g-4">
        {movies.length ? movies.map(movie => (
          <div key={movie.id} className="col-lg-4 col-md-6 col-sm-12">
            <div className="card h-100 rounded-4 overflow-hidden shadow-sm movie-card">
              <div className="card-body text-center bg-light">
                <h5 className="card-title fw-bold">{movie.title}</h5>
                <p className="mb-1"><strong>Director:</strong> {movie.director}</p>
                <p className="mb-2">
                  <span className="badge bg-danger me-1">{movie.genre}</span>
                  <span className="badge bg-primary me-1">{movie.platform}</span>
                  <span className="badge bg-success">{movie.status}</span>
                </p>
                <button
                  className="btn btn-outline-danger mt-2"
                  onClick={() => handleDetails(movie.id)}
                >
                  Details
                </button>
              </div>
            </div>
          </div>
        )) : (
          <div className="col-12">
            <p className="text-center fs-5">No results found.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Search;
