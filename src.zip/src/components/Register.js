import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { userRegister } from '../services/Apicall';

function Register() {
  const navigate = useNavigate();
  const [user, setUser] = useState({ username:'', password:'', email:'', first_name:'', last_name:'' });

  async function register(event) {
    event.preventDefault();
    try {
      await userRegister(user);
      navigate('/login');
    } catch (err) {
      console.error(err);
      alert("Registration failed!");
    }
  }

  return (
    <div className="container w-50 fw-bold fs-5 text-light border border-1 border-danger shadow p-5">
      <h2 className="text-center text-light mt-2">Add User Details</h2>
      <form onSubmit={register}>
        <div className="mb-3">
          <label className="form-label">Username</label>
          <input type="text" className="form-control" placeholder="Enter Username"
            value={user.username} onChange={e => setUser({ ...user, username: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" className="form-control" placeholder="Enter Password"
            value={user.password} onChange={e => setUser({ ...user, password: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">First Name</label>
          <input type="text" className="form-control" placeholder="Enter Firstname"
            value={user.first_name} onChange={e => setUser({ ...user, first_name: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Last Name</label>
          <input type="text" className="form-control" placeholder="Enter Lastname"
            value={user.last_name} onChange={e => setUser({ ...user, last_name: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input type="email" className="form-control" placeholder="Enter Email"
            value={user.email} onChange={e => setUser({ ...user, email: e.target.value })} />
        </div>
        <div className="mb-3">
          <input type="submit" className="form-control btn btn-danger" value="Register" />
        </div>
      </form>
    </div>
  );
}

export default Register;
