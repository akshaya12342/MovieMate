import React, { useEffect, useState } from 'react';
import { getAllMovies } from '../services/Apicall';
import { useNavigate } from 'react-router-dom';

function Home() {
  const [movies, setMovies] = useState([]);
  const [filters, setFilters] = useState({ genre: '', platform: '', status: '', sort: '' });
  const navigate = useNavigate();

  const fetchMovies = async () => {
    try {
      const res = await getAllMovies();
      setMovies(res.data || []);
    } catch (err) {
      console.error('Failed fetching movies:', err);
      setMovies([]);
    }
  };

  useEffect(() => { fetchMovies(); }, []);

  const filteredMovies = movies
    .filter(m => !filters.genre || m.genre === filters.genre)
    .filter(m => !filters.platform || m.platform === filters.platform)
    .filter(m => !filters.status || m.status === filters.status)
    .sort((a, b) => {
      if (filters.sort === 'title-asc') return a.title.localeCompare(b.title);
      if (filters.sort === 'title-desc') return b.title.localeCompare(a.title);
      return 0;
    });

  const handleDetails = (id) => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please login to view details.');
      navigate('/login');
    } else {
      navigate(`/detail?id=${id}`);
    }
  };

  const clearFilters = () => setFilters({ genre: '', platform: '', status: '', sort: '' });

  return (
    <div className="container mt-5">

 <div
  className="position-relative text-center text-white rounded-4 mb-5"
  style={{
    background: 'linear-gradient(135deg, #ff416c, #ff4b2b)',
    padding: '4rem 2rem',
    overflow: 'hidden',
    borderRadius: '1rem',
    boxShadow: '0 10px 25px rgba(0,0,0,0.2)'
  }}
>
  <div className="position-absolute w-100 h-100 top-0 start-0" style={{ pointerEvents: 'none' }}>
    {[...Array(8)].map((_, i) => (
      <span
        key={i}
        style={{
          position: 'absolute',
          width: `${20 + Math.random() * 30}px`,
          height: `${20 + Math.random() * 30}px`,
          borderRadius: '50%',
          background: 'rgba(255,255,255,0.2)',
          top: `${Math.random() * 100}%`,
          left: `${Math.random() * 100}%`,
          animation: `floatAnimation ${5 + Math.random() * 5}s ease-in-out infinite alternate`
        }}
      />
    ))}
  </div>
  <h1 className="fw-bold display-4" style={{ textShadow: '2px 2px 8px rgba(0,0,0,0.5)' }}>
    Welcome to MovieMate
  </h1>
  <p className="lead fs-5" style={{ textShadow: '1px 1px 6px rgba(0,0,0,0.3)' }}>
    Discover, track, and review your favorite movies and shows!
  </p>
  <style>{`
    @keyframes floatAnimation {
      0% { transform: translateY(0px); }
      100% { transform: translateY(-20px); }
    }
  `}</style>
</div>


      <div className="d-flex flex-wrap justify-content-center gap-2 mb-4 align-items-center">
        <select className="form-select w-auto" value={filters.genre} onChange={e => setFilters({ ...filters, genre: e.target.value })}>
          <option value="">All Genres</option>
          <option>Action</option>
          <option>Comedy</option>
          <option>Drama</option>
          <option>Horror</option>
          <option>Romance</option>
          <option>Sci-Fi</option>
          <option>Documentary</option>
        </select>
        <select className="form-select w-auto" value={filters.platform} onChange={e => setFilters({ ...filters, platform: e.target.value })}>
          <option value="">All Platforms</option>
          <option>Netflix</option>
          <option>Prime Video</option>
          <option>Disney+</option>
          <option>HBO</option>
          <option>Other</option>
        </select>
        <select className="form-select w-auto" value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })}>
          <option value="">All Status</option>
          <option>Watching</option>
          <option>Completed</option>
          <option>Wishlist</option>
        </select>

        <button className="btn btn-outline-light" onClick={clearFilters}>Clear Filters</button>
      </div>

      <div className="row g-4">
        {filteredMovies.length ? filteredMovies.map(movie => (
          <div className="col-lg-4 col-md-6 col-sm-12" key={movie.id}>
            <div className="card h-100 rounded-4 overflow-hidden">
              <div
                className="d-flex align-items-center justify-content-center text-white fs-2 fw-bold"
                style={{
                  background: `rgba(0,0,0,0.3) url('/images/${movie.id}.jpg') center/cover no-repeat`,
                  height: '220px',
                }}
              >
                {movie.title.charAt(0)}
              </div>
  <div
  className="card-body text-center rounded-4 shadow-sm"
  style={{
    background: 'linear-gradient(135deg, #FFD194, #D1913C)', // soft warm gradient
    padding: '1.5rem',
    transition: 'transform 0.3s, box-shadow 0.3s'
  }}
>
  <h5 className="card-title fw-bold mb-3">{movie.title}</h5>
  <p className="mb-3">
    <span className="badge bg-warning text-dark me-1 shadow-sm" style={{ fontSize: '0.9rem' }}>{movie.genre}</span>
    <span className="badge bg-info text-dark me-1 shadow-sm" style={{ fontSize: '0.9rem' }}>{movie.platform}</span>
    <span className="badge bg-success text-dark shadow-sm" style={{ fontSize: '0.9rem' }}>{movie.status}</span>
  </p>
  <button
    className="btn btn-light fw-bold"
    style={{
      transition: 'transform 0.2s, box-shadow 0.2s'
    }}
    onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
    onClick={() => handleDetails(movie.id)}
  >
    Details
  </button>

  <style>{`
    .card-body:hover {
      transform: translateY(-5px) scale(1.02);
      box-shadow: 0 12px 25px rgba(0,0,0,0.15);
    }
  `}</style>
</div>


            </div>
          </div>
        )) : (
          <div className="col-12">
            <p className="text-center fs-5">No movies found. Try adjusting your filters!</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;

