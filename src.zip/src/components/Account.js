import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
const BASE_URL = "http://127.0.0.1:8000";

function Account() {
  const [user, setUser] = useState({});
  const [movies, setMovies] = useState([]);
  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const tab = queryParams.get('tab') || 'profile';

  const token = localStorage.getItem('token');
  const headers = token ? { Authorization: `Token ${token}` } : {};

  const fetchUser = async () => {
    try {
      const res = await axios.get(`${BASE_URL}/users/me/`, { headers });
      setUser(res.data);
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const fetchMovies = async () => {
    if (!token) return;
    try {
      const url =
        tab === 'watched'
          ? `${BASE_URL}/movies/?status=Completed`
          : `${BASE_URL}/movies/?status=Wishlist`;
      const res = await axios.get(url, { headers });
      setMovies(res.data || []);
    } catch (error) {
      console.error('Error fetching movies:', error);
    }
  };

  useEffect(() => {
    if (token) {
      fetchUser();
      if (tab === 'watched' || tab === 'wishlist') fetchMovies();
    }
  }, [tab]);

  const watchedMovies = movies.filter(m => m.status === 'Completed');
  const wishlistMovies = movies.filter(m => m.status === 'Wishlist');

  return (
    <div className="container mt-5">
      <h2 className="text-center text-light mb-4">My Account</h2>

      {tab === 'profile' && (
        <div className="card p-4 bg-light text-dark">
          <h4>User Details</h4>
          <p><strong>Username:</strong> {user.username}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>First Name:</strong> {user.first_name}</p>
          <p><strong>Last Name:</strong> {user.last_name}</p>
        </div>
      )}

      {(tab === 'watched' || tab === 'wishlist') && (
        <div className="mt-4">
          <h4>{tab === 'watched' ? 'Watched Movies' : 'Wishlist Movies'}</h4>
          {movies.length === 0 ? (
            <p>No movies to display.</p>
          ) : (
            <div className="row">
              {movies.map((movie) => (
                <div className="col-4 mb-3" key={movie.id}>
                  <div className="card">
                    <img
                      src={movie.image || '/placeholder.png'}
                      className="card-img-top"
                      alt={movie.title}
                      style={{ height: '250px', objectFit: 'cover' }}
                    />
                    <div className="card-body text-center">
                      <h5 className="card-title">{movie.title}</h5>
                      <p>{movie.platform} | {movie.status}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Account;
