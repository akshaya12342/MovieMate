import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { userLogin } from '../services/Apicall';

function Login({ onLogin }) {
  const navigate = useNavigate();
  const [user, setUser] = useState({ username: '', password: '' });
  const [loading, setLoading] = useState(false);

  const login = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const res = await userLogin(user);
      if (res.data && res.data.token) {
        localStorage.setItem('token', res.data.token);
        onLogin && onLogin();
        navigate('/');
      } else {
        alert('Login failed: invalid response from server.');
      }
    } catch (err) {
      console.error('Login error:', err.response || err);
      const msg = err.response?.data?.non_field_errors?.[0] || err.response?.data?.detail || 'Login failed: check credentials';
      alert(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container w-50 fw-bold fs-5 border border-1 border-danger shadow p-5 mt-5">
      <h2 className="text-center mt-2 mb-4">Login</h2>
      <form onSubmit={login}>
        <div className="mb-3">
          <label className="form-label">Username</label>
          <input
            type="text"
            className="form-control"
            required
            value={user.username}
            onChange={(e) => setUser({ ...user, username: e.target.value })}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            required
            value={user.password}
            onChange={(e) => setUser({ ...user, password: e.target.value })}
          />
        </div>
        <div className="mb-3">
          <button className="btn btn-danger w-100" type="submit" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </div>
      </form>

      <div className="text-center mt-3">
        <p>
          Don't have an account?{' '}
          <Link to="/register" className="text-danger fw-bold">
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
