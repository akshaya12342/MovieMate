import React, { useState, useEffect } from 'react';
import { addMovieDetails } from '../services/Apicall';
import { useNavigate } from 'react-router-dom';

function Add() {
  const navigate = useNavigate();
  const [movie, setMovie] = useState({ title: '', genre: '', director: '', platform: '', status: '' });

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
    }
  }, [navigate]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      Object.keys(movie).forEach(k => formData.append(k, movie[k]));
      await addMovieDetails(formData);
      navigate('/');
    } catch (err) {
      console.error(err);
      alert('Failed to add movie. Please try again.');
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-lg-6 col-md-8">
          <div className="card shadow-sm p-4">
            <h3 className="text-center mb-4">Add Movie</h3>
            <form onSubmit={submit}>
              <div className="mb-3">
                <input
                  className="form-control"
                  placeholder="Title"
                  value={movie.title}
                  onChange={e => setMovie({ ...movie, title: e.target.value })}
                  required
                />
              </div>
              <div className="mb-3">
                <input
                  className="form-control"
                  placeholder="Director"
                  value={movie.director}
                  onChange={e => setMovie({ ...movie, director: e.target.value })}
                  required
                />
              </div>
              <div className="mb-3">
                <select
                  className="form-select"
                  value={movie.genre}
                  onChange={e => setMovie({ ...movie, genre: e.target.value })}
                  required
                >
                  <option value="">Select Genre</option>
                  <option>Action</option>
                  <option>Comedy</option>
                  <option>Drama</option>
                  <option>Horror</option>
                  <option>Romance</option>
                  <option>Sci-Fi</option>
                  <option>Documentary</option>
                </select>
              </div>
              <div className="mb-3">
                <select
                  className="form-select"
                  value={movie.platform}
                  onChange={e => setMovie({ ...movie, platform: e.target.value })}
                  required
                >
                  <option value="">Select Platform</option>
                  <option>Netflix</option>
                  <option>Prime Video</option>
                  <option>Disney+</option>
                  <option>HBO</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="mb-4">
                <select
                  className="form-select"
                  value={movie.status}
                  onChange={e => setMovie({ ...movie, status: e.target.value })}
                  required
                >
                  <option value="">Select Status</option>
                  <option>Watching</option>
                  <option>Completed</option>
                  <option>Wishlist</option>
                </select>
              </div>
              <div className="d-grid">
                <button className="btn btn-danger btn-lg" type="submit">Add Movie</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Add;
