import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { getMoviedetails, updateMoviedetails } from '../services/Apicall';

function Update() {
  const [movie, setMovie] = useState({ title:'', director:'', genre:'', platform:'', status:'' });
  const { search } = useLocation();
  const navigate = useNavigate();
  const id = new URLSearchParams(search).get('id');

  useEffect(()=> {
    if (!id) return;
    (async ()=> {
      try {
        const res = await getMoviedetails(id);
        setMovie(res.data || {});
      } catch (err) { console.error(err); }
    })();
  }, [id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      Object.keys(movie).forEach(k => formData.append(k, movie[k]));
      await updateMoviedetails(id, formData);
      navigate(`/detail?id=${id}`);
    } catch (err) {
      console.error(err);
      alert('Update failed');
    }
  };

  return (
    <div className="container w-50 mt-4">
      <h3>Update Movie</h3>
      <form onSubmit={submit}>
        <input className="form-control mb-2" value={movie.title} onChange={e=>setMovie({...movie, title:e.target.value})} required/>
        <input className="form-control mb-2" value={movie.director} onChange={e=>setMovie({...movie, director:e.target.value})}/>
        <select className="form-control mb-2" value={movie.genre} onChange={e=>setMovie({...movie, genre:e.target.value})}>
          <option value="">Select Genre</option>
          <option>Action</option><option>Comedy</option><option>Drama</option><option>Horror</option><option>Sci-Fi</option>
        </select>
        <select className="form-control mb-2" value={movie.platform} onChange={e=>setMovie({...movie, platform:e.target.value})}>
          <option value="">Platform</option><option>Netflix</option><option>Prime Video</option><option>Disney+</option><option>HBO</option><option>Other</option>
        </select>
        <select className="form-control mb-2" value={movie.status} onChange={e=>setMovie({...movie, status:e.target.value})}>
          <option value="">Status</option><option>Watching</option><option>Completed</option><option>Wishlist</option>
        </select>
        <button className="btn btn-primary" type="submit">Update</button>
      </form>
    </div>
  );
}

export default Update;
