import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { getMoviedetails, deleteMovieDetails, allReviews } from '../services/Apicall';

function Detail() {
  const [movie, setMovie] = useState({});
  const [reviews, setReviews] = useState([]);
  const navigate = useNavigate();
  const { search } = useLocation();
  const query = new URLSearchParams(search);
  const id = query.get('id');

  useEffect(() => {
    if (!id) return;
    (async () => {
      try {
        const res = await getMoviedetails(id);
        setMovie(res.data || {});
      } catch (err) {
        console.error(err);
      }
      try {
        const r = await allReviews(id);
        setReviews(r.data || []);
      } catch (err) {
        console.error(err);
      }
    })();
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Delete this movie?')) return;
    try {
      await deleteMovieDetails(id);
      navigate('/');
    } catch (err) {
      console.error(err);
      alert('Cannot delete movie. Check console.');
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span key={i} className={i <= rating ? 'text-warning' : 'text-secondary'}>
          ★
        </span>
      );
    }
    return stars;
  };

  return (
    <div className="container mt-5">
      <div className="position-relative mb-5">
        <div
          className="rounded-4 overflow-hidden hero-header"
          style={{
            background: `linear-gradient(to right, rgba(255,255,255,0.1), rgba(255,255,255,0.05)), url('/images/${movie.id}.jpg') center/cover no-repeat`,
            height: '300px'
          }}
        ></div>

        <div className="movie-card card shadow-lg position-absolute top-50 start-50 translate-middle w-100" style={{ maxWidth: '900px', border: '2px solid #dee2e6', padding: '2rem', transition: 'transform 0.3s, box-shadow 0.3s' }}>
          <div className="card-body text-center">
            <h2 className="fw-bold">{movie.title}</h2>
            <p className="text-muted mb-2">{movie.genre} • {movie.platform} • Status: {movie.status}</p>
            <p>Directed by: <strong>{movie.director}</strong></p>
            <div className="d-flex flex-wrap justify-content-center gap-3 mt-3">
              <button className="btn btn-outline-primary" onClick={() => navigate(`/update?id=${id}`)}>Edit</button>
              <button className="btn btn-outline-danger" onClick={handleDelete}>Delete</button>
              <button className="btn btn-outline-success" onClick={() => navigate(`/addreview?id=${id}`)}>Add Review</button>
            </div>
          </div>
        </div>
      </div>
      <div className="reviews-section py-5 px-3 rounded-4" style={{ background: 'linear-gradient(to bottom, #f8f9fa, #e9ecef)' }}>
        <h4 className="mb-4 text-center">Reviews</h4>
        {reviews.length ? (
          <div className="row g-3">
            {reviews.map(rv => (
              <div className="col-md-6" key={rv.id}>
                <div className="card shadow-sm h-100 border-0">
                  <div className="card-body bg-white rounded-3">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <strong>{rv.user}</strong>
                      <span>{renderStars(rv.rating)}</span>
                    </div>
                    <p className="mb-0">{rv.comment}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted fs-5">No reviews yet. Be the first to add one!</p>
        )}
      </div>
      <style>{`
        .movie-card:hover {
          transform: scale(1.03);
          box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }
      `}</style>
    </div>
  );
}

export default Detail;


