import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { userLogout } from '../services/Apicall';

function Navbar({ isLoggedIn, onLogout }) {
  const navigate = useNavigate();
  const [word, setWord] = useState('');
  const [username, setUsername] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setUsername('Me');
    } else {
      setUsername('');
    }
  }, [isLoggedIn]);

  const doSearch = (e) => {
    e?.preventDefault();
    if (!word.trim()) return;
    navigate(`/search?word=${encodeURIComponent(word)}`);
    setWord('');
  };

  const logout = async () => {
    try {
      await userLogout();
    } catch (err) {
      console.error(err);
    } finally {
      localStorage.removeItem('token');
      onLogout && onLogout();
      navigate('/login');
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">MovieMate</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
 
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>

         
            {isLoggedIn && (
              <li className="nav-item">
                <Link className="nav-link" to="/add">Add Movie</Link>
              </li>
            )}
          </ul>

          <form className="d-flex me-3" onSubmit={doSearch}>
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search Movies"
              value={word}
              onChange={e => setWord(e.target.value)}
            />
            <button className="btn btn-outline-light" type="submit">Search</button>
          </form>

          <ul className="navbar-nav">
            {!isLoggedIn && <>
              <li className="nav-item"><Link to="/register" className="nav-link">Register</Link></li>
              <li className="nav-item"><Link to="/login" className="nav-link">Login</Link></li>
            </>}

            {isLoggedIn && (
              <li className="nav-item dropdown">
                <span
                  className="nav-link dropdown-toggle"
                  role="button"
                  data-bs-toggle="dropdown"
                  style={{ cursor: 'pointer' }}
                >
                  My Account {username && `(${username})`}
                </span>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li><Link className="dropdown-item" to="/account?tab=profile">Profile</Link></li>
                  <li><Link className="dropdown-item" to="/account?tab=watched">Watched</Link></li>
                  <li><Link className="dropdown-item" to="/account?tab=wishlist">Wishlist</Link></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <span
                      className="dropdown-item text-danger"
                      onClick={logout}
                      style={{ cursor: 'pointer' }}
                    >
                      Logout
                    </span>
                  </li>
                </ul>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
