import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { addReviewDetail } from '../services/Apicall';

function Addreview({ isLoggedIn }) {
  const { search } = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(search);
  const movieId = query.get('id');
  const [review, setReview] = useState({ rating:'', comment:'' });
  const [error, setError] = useState('');

  useEffect(()=> {
    if (!isLoggedIn) navigate('/login');
  }, [isLoggedIn, navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!review.rating || !review.comment) { setError('Rating and comment required'); return; }
    if (review.rating < 1 || review.rating > 5) { setError('Rating 1-5'); return; }
    try {
      await addReviewDetail({ id: movieId, rating: review.rating, comment: review.comment });
      navigate(`/detail?id=${movieId}`);
    } catch (err) {
      console.error(err);
      setError('Failed to submit review.');
    }
  };

  return (
    <div className="container w-50 mt-4">
      <h3>Add Review</h3>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={submit}>
        <textarea className="form-control mb-2" value={review.comment} onChange={e=>setReview({...review, comment: e.target.value})} placeholder="Comment" required />
        <input className="form-control mb-2" type="number" min="1" max="5" value={review.rating} onChange={e=>setReview({...review, rating: e.target.value})} placeholder="Rating (1-5)" required />
        <button className="btn btn-primary" type="submit">Submit Review</button>
      </form>
    </div>
  );
}

export default Addreview;
