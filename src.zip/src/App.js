import './App.css';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

import Navbar from './components/Navbar';
import Home from './components/Home';
import Detail from './components/Detail';
import Update from './components/Update';
import Register from './components/Register';
import Login from './components/Login';
import Search from './components/Search';
import Addreview from './components/Addreview';
import Add from './components/Add';
import Account from './components/Account';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const checkLoginStatus = () => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  };

  useEffect(() => {
    checkLoginStatus();
  }, []);

  return (
    <div className="App">
      <BrowserRouter>
        <Navbar isLoggedIn={isLoggedIn} onLogout={checkLoginStatus} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/detail" element={<Detail />} />
          <Route path="/update" element={<Update />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login onLogin={checkLoginStatus} />} />
          <Route path="/search" element={<Search />} />
          <Route
            path="/addreview"
            element={isLoggedIn ? <Addreview isLoggedIn={isLoggedIn} /> : <Navigate to="/login" />}
          />
          <Route path="/add" element={isLoggedIn ? <Add /> : <Navigate to='/login' />} />
          <Route
            path="/account"
            element={isLoggedIn ? <Account /> : <Navigate to='/login' />}
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
