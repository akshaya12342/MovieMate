import axios from "axios";

const BASE_URL = "http://127.0.0.1:8000";

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return token ? { Authorization: `Token ${token}` } : {};
};

export async function getAllMovies() {
  return axios.get(`${BASE_URL}/movies/`);
}

export async function getMoviedetails(id) {
  return axios.get(`${BASE_URL}/movies/${id}/`);
}

export async function addMovieDetails(data) {
  return axios.post(`${BASE_URL}/movies/`, data, {
    headers: { ...getAuthHeaders(), "Content-Type": "multipart/form-data" },
  });
}

export async function updateMoviedetails(id, data) {
  return axios.put(`${BASE_URL}/movies/${id}/`, data, {
    headers: { ...getAuthHeaders(), "Content-Type": "multipart/form-data" },
  });
}

export async function deleteMovieDetails(id) {
  return axios.delete(`${BASE_URL}/movies/${id}/`, { headers: getAuthHeaders() });
}

export async function searchMovieDetails(word) {
  return axios.get(`${BASE_URL}/movie_search/`, { params: { search: word } });
}

export async function userRegister(data) {
  return axios.post(`${BASE_URL}/users/`, data);
}

export async function userLogin(data) {
  return axios.post(`${BASE_URL}/login/`, data);
}

export async function userLogout() {
  return axios.get(`${BASE_URL}/logout/`, { headers: getAuthHeaders() });
}

export async function allReviews(id) {
  return axios.get(`${BASE_URL}/review_filter/${id}/`);
}

export async function addReviewDetail(data) {
  return axios.post(`${BASE_URL}/create_review/`, data, { headers: getAuthHeaders() });
}
